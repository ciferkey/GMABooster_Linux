-----------------------------------------------------------------------------------------------
06/25/2009                          GMABooster for Linux                         (Version 0.9c)
-----------------------------------------------------------------------------------------------

WARRANTY DISCLAIMER: USE THIS EXPERIMENTAL BUILD AT YOUR OWN RISK!

GMABooster for Linux is an effort to bring Intel GMA 950 overclocking capability to Linux users.
This is a branch of GMABooster project. Please visit http://www.gmabooster.com for details.

Please read the information below carefully before using the program.

Compatibility: Linux (x86/32 bit, kernel 2.6.28 or higher).

Prerequisite: Intel 2008Q4 graphics package (http://intellinuxgraphics.org/2008Q4.html)

GMABooster may (or may not!) work with earlier kernel and/or graphics package versions.
If You think You have found a defect in the program, please, verify that Your system meets
the requirements above before contacting support (support@gmabooster.com)

What's new in version 0.9c:
1. Ability to reset GMA 950 core clock to 166 MHz without a need to restart computer or put it
into standby.
2. Ability to detect and display a current GMA 950 core clock setting.

Program usage: MAKE SURE YOU HAVE LOGGED IN AS ROOT, launch GMABooster via terminal
and follow the simple on screen instructions (if required do "chmod +x GMABooster" first).
Alternatively, you can use the command line arguments: 400, 250, 200, 166, --detect
(e.g. "./GMABooster 400" to apply 400 MHz setting, or "./GMABooster --detect" to read a current
GMA 950 core clock and exit).

GMABooster for Linux is a free software.
If You have found the program to be useful, please consider a donation to help me
make it even better. Please visit http://www.gmabooster.com for details. Thank You!

Copyright notice: GMABooster software product is copyright (C)2009 Vladimir Plenskiy.
All other trademarks are the property of their respective owners.
